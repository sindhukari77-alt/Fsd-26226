<?php
$conn = mysqli_connect("localhost", "root", "", "college_db",3307);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}
?>