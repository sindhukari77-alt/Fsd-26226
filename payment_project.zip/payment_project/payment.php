<?php
$conn = mysqli_connect("localhost", "root", "", "payment_system",3307);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$message = "";
$userBalance = "";
$merchantBalance = "";

if(isset($_POST['pay'])) {

    $user_id = $_POST['user_id'];
    $merchant_id = $_POST['merchant_id'];
    $amount = $_POST['amount'];

    mysqli_begin_transaction($conn);

    try {

        // Get user balance
        $userQuery = mysqli_query($conn, "SELECT balance FROM users WHERE user_id=$user_id");
        $userData = mysqli_fetch_assoc($userQuery);

        if(!$userData) {
            throw new Exception("User not found!");
        }

        if($userData['balance'] < $amount) {
            throw new Exception("Insufficient Balance!");
        }

        // Deduct from user
        $updateUser = mysqli_query($conn, 
            "UPDATE users SET balance = balance - $amount WHERE user_id=$user_id");

        if(!$updateUser) {
            throw new Exception("Failed to deduct amount from user.");
        }

        // Add to merchant
        $updateMerchant = mysqli_query($conn, 
            "UPDATE merchants SET balance = balance + $amount WHERE merchant_id=$merchant_id");

        if(!$updateMerchant) {
            throw new Exception("Failed to add amount to merchant.");
        }

        mysqli_commit($conn);

        $message = "✅ Payment Successful! Transaction Committed.";

        // Fetch updated balances
        $userBalanceData = mysqli_fetch_assoc(
            mysqli_query($conn, "SELECT balance FROM users WHERE user_id=$user_id")
        );

        $merchantBalanceData = mysqli_fetch_assoc(
            mysqli_query($conn, "SELECT balance FROM merchants WHERE merchant_id=$merchant_id")
        );

        $userBalance = "User New Balance: ₹" . $userBalanceData['balance'];
        $merchantBalance = "Merchant New Balance: ₹" . $merchantBalanceData['balance'];

    } catch (Exception $e) {

        mysqli_rollback($conn);

        $message = "❌ Payment Failed! Transaction Rolled Back. " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Payment System</title>
<style>
body {
    font-family: Arial;
    background: #f4f4f4;
}
.container {
    width: 400px;
    margin: 80px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
}
h2 {
    text-align: center;
}
input, select {
    width: 100%;
    padding: 8px;
    margin: 10px 0;
}
button {
    width: 100%;
    padding: 10px;
    background: green;
    color: white;
    border: none;
    cursor: pointer;
}
.message {
    text-align: center;
    margin-top: 15px;
    font-weight: bold;
}
.balance {
    text-align: center;
    margin-top: 10px;
    color: blue;
}
</style>
</head>
<body>

<div class="container">
<h2>Online Payment</h2>

<form method="POST">
    <label>Select User</label>
    <select name="user_id">
        <option value="1">Ravi</option>
        <option value="2">Anjali</option>
    </select>

    <label>Select Merchant</label>
    <select name="merchant_id">
        <option value="1">Amazon</option>
    </select>

    <label>Enter Amount</label>
    <input type="number" name="amount" required>

    <button type="submit" name="pay">Pay Now</button>
</form>

<div class="message">
    <?php echo $message; ?>
</div>

<div class="balance">
    <?php 
    echo $userBalance . "<br>";
    echo $merchantBalance;
    ?>
</div>

</div>

</body>
</html>