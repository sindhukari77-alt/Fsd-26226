<?php
$conn = mysqli_connect("localhost", "root", "", "audit_system",3307);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT * FROM daily_activity";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Employee Activity Logs</title>
<style>
body {
    font-family: Arial;
    background-color: #f4f4f4;
}
h2 {
    text-align: center;
}
table {
    width: 80%;
    margin: 30px auto;
    border-collapse: collapse;
    background: white;
}
th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}
th {
    background-color: #007bff;
    color: white;
}
</style>
</head>
<body>

<h2>Employee Daily Activity Logs</h2>

<table>
<tr>
    <th>Employee ID</th>
    <th>Action Type</th>
    <th>Old Salary</th>
    <th>New Salary</th>
    <th>Action Date</th>
</tr>

<?php
while($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
            <td>{$row['emp_id']}</td>
            <td>{$row['action_type']}</td>
            <td>{$row['old_salary']}</td>
            <td>{$row['new_salary']}</td>
            <td>{$row['action_date']}</td>
          </tr>";
}
?>

</table>

</body>
</html>